from warehouse_env import WarehouseEnv, GameObject, Robot, Package, Floor

def test_environment_logic():
    print("Initializing environment...")
    # render_mode=None ensures no pygame window is needed
    env = WarehouseEnv(render_mode=None)
    
    # 1. Verify OOP Structure
    print("\nVerifying OOP Structure:")
    obs, info = env.reset()
    agent = env._agent
    target = env._target
    
    print(f"Agent type: {type(agent).__name__}, Inherits GameObject: {isinstance(agent, GameObject)}")
    print(f"Target type: {type(target).__name__}, Inherits GameObject: {isinstance(target, GameObject)}")
    
    assert isinstance(agent, Robot)
    assert isinstance(agent, GameObject)
    assert isinstance(target, Package)
    assert isinstance(target, GameObject)
    print("OOP Inheritance verified.")

    # 2. Verify Interaction Logic
    print("\nVerifying Interaction Logic:")
    # We cheat and move the agent right next to the target to test interaction
    env._agent.x = target.x
    env._agent.y = target.y 
    # Move 'on top' of it effectively
    
    # Manually call interaction
    moved, reward, done = target.interact(agent)
    print(f"Interact Result: Moved={moved}, Reward={reward}, Done={done}")
    
    assert reward == 100.0
    assert done == True
    print("Interaction logic verified.")

    # 3. Verify Wall/Floor Logic
    print("\nVerifying Floor Logic:")
    floor = Floor(0, 0)
    moved, reward, done = floor.interact(agent)
    print(f"Floor Interact Result: Moved={moved}, Reward={reward}, Done={done}")
    assert moved == True
    assert reward < 0 # Small penalty
    assert done == False
    
    print("\nAll tests passed!")

if __name__ == "__main__":
    test_environment_logic()
