from abc import ABC, abstractmethod
import numpy as np
import pickle
import os

# --- OOP: Abstract Base Class for Agents ---
class Agent(ABC):
    """
    Abstract base class for all agents.
    Demonstrates Abstraction and Polymorphism.
    Different agent types can implement different learning strategies.
    """
    
    @abstractmethod
    def select_action(self, observation, training=True):
        """
        Select an action based on the current observation.
        
        Args:
            observation: Current state observation
            training: Whether agent is in training mode (affects exploration)
        
        Returns:
            action: Integer action to take
        """
        pass
    
    @abstractmethod
    def learn(self, state, action, reward, next_state, done):
        """
        Update agent's knowledge based on experience.
        
        Args:
            state: Previous state
            action: Action taken
            reward: Reward received
            next_state: Resulting state
            done: Whether episode ended
        """
        pass
    
    @abstractmethod
    def save(self, filepath):
        """Save agent's learned parameters to file"""
        pass
    
    @abstractmethod
    def load(self, filepath):
        """Load agent's learned parameters from file"""
        pass


# --- OOP: Concrete Agent Implementation 1 (Baseline) ---
class RandomAgent(Agent):
    """
    Random agent that takes random actions.
    Useful as a baseline for comparison.
    """
    
    def __init__(self, action_space_size):
        self.action_space_size = action_space_size
    
    def select_action(self, observation, training=True):
        """Randomly select an action"""
        return np.random.randint(0, self.action_space_size)
    
    def learn(self, state, action, reward, next_state, done):
        """Random agent doesn't learn"""
        pass
    
    def save(self, filepath):
        """Nothing to save for random agent"""
        pass
    
    def load(self, filepath):
        """Nothing to load for random agent"""
        pass


# --- OOP: Concrete Agent Implementation 2 (Q-Learning) ---
class QLearningAgent(Agent):
    """
    Q-Learning agent using tabular Q-table.
    Demonstrates Encapsulation: Learning logic is self-contained.
    """
    
    def __init__(self, action_space_size, learning_rate=0.1, discount_factor=0.95,
                 epsilon_start=1.0, epsilon_end=0.01, epsilon_decay=0.995):
        """
        Initialize Q-Learning agent.
        
        Args:
            action_space_size: Number of possible actions
            learning_rate: Alpha parameter for Q-learning
            discount_factor: Gamma parameter for future rewards
            epsilon_start: Initial exploration rate
            epsilon_end: Minimum exploration rate
            epsilon_decay: Decay rate for epsilon
        """
        self.action_space_size = action_space_size
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.epsilon = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay
        
        # Q-table: nested dictionary {state: {action: q_value}}
        self.q_table = {}
        
        # Statistics
        self.total_updates = 0
    
    def _state_to_key(self, observation):
        """Convert observation array to hashable tuple for Q-table lookup"""
        return tuple(observation)
    
    def _get_q_value(self, state, action):
        """Get Q-value for state-action pair, initialize if not exists"""
        state_key = self._state_to_key(state)
        if state_key not in self.q_table:
            self.q_table[state_key] = {a: 0.0 for a in range(self.action_space_size)}
        return self.q_table[state_key][action]
    
    def _set_q_value(self, state, action, value):
        """Set Q-value for state-action pair"""
        state_key = self._state_to_key(state)
        if state_key not in self.q_table:
            self.q_table[state_key] = {a: 0.0 for a in range(self.action_space_size)}
        self.q_table[state_key][action] = value
    
    def select_action(self, observation, training=True):
        """
        Epsilon-greedy action selection.
        
        Args:
            observation: Current state
            training: If True, use epsilon-greedy; if False, use greedy
        
        Returns:
            Selected action
        """
        if training and np.random.random() < self.epsilon:
            # Explore: random action
            return np.random.randint(0, self.action_space_size)
        else:
            # Exploit: best known action
            state_key = self._state_to_key(observation)
            if state_key not in self.q_table:
                return np.random.randint(0, self.action_space_size)
            
            # Get action with highest Q-value
            q_values = self.q_table[state_key]
            max_q = max(q_values.values())
            # Handle ties by random selection among best actions
            best_actions = [a for a, q in q_values.items() if q == max_q]
            return np.random.choice(best_actions)
    
    def learn(self, state, action, reward, next_state, done):
        """
        Q-Learning update rule:
        Q(s,a) = Q(s,a) + α * [r + γ * max(Q(s',a')) - Q(s,a)]
        """
        current_q = self._get_q_value(state, action)
        
        if done:
            # Terminal state: no future rewards
            target_q = reward
        else:
            # Get max Q-value for next state
            next_state_key = self._state_to_key(next_state)
            if next_state_key in self.q_table:
                max_next_q = max(self.q_table[next_state_key].values())
            else:
                max_next_q = 0.0
            
            target_q = reward + self.discount_factor * max_next_q
        
        # Update Q-value
        new_q = current_q + self.learning_rate * (target_q - current_q)
        self._set_q_value(state, action, new_q)
        
        self.total_updates += 1
    
    def decay_epsilon(self):
        """Decay exploration rate"""
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)
    
    def save(self, filepath):
        """Save Q-table and parameters to file"""
        data = {
            'q_table': self.q_table,
            'epsilon': self.epsilon,
            'learning_rate': self.learning_rate,
            'discount_factor': self.discount_factor,
            'total_updates': self.total_updates
        }
        
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'wb') as f:
            pickle.dump(data, f)
        print(f"Agent saved to {filepath}")
    
    def load(self, filepath):
        """Load Q-table and parameters from file"""
        if not os.path.exists(filepath):
            print(f"No saved agent found at {filepath}")
            return False
        
        with open(filepath, 'rb') as f:
            data = pickle.load(f)
        
        self.q_table = data['q_table']
        self.epsilon = data['epsilon']
        self.learning_rate = data['learning_rate']
        self.discount_factor = data['discount_factor']
        self.total_updates = data.get('total_updates', 0)
        
        print(f"Agent loaded from {filepath}")
        print(f"Q-table size: {len(self.q_table)} states")
        print(f"Total updates: {self.total_updates}")
        return True
    
    def get_stats(self):
        """Get agent statistics"""
        return {
            'q_table_size': len(self.q_table),
            'epsilon': self.epsilon,
            'total_updates': self.total_updates
        }
