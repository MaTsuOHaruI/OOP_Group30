import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pygame
import os
from abc import ABC, abstractmethod

# --- OOP: Abstraction & Inheritance ---
class GameObject(ABC):
    """
    Abstract Base Class representing any object in the warehouse grid.
    Demonstrates Abstraction: Hides low-level rendering details.
    Demonstrates Inheritance: Common attributes for all objects.
    """
    def __init__(self, x, y, image_path=None, color=None):
        self.x = x
        self.y = y
        self.image = None
        self.color = color or (100, 100, 100)
        
        if image_path and os.path.exists(image_path):
            self.image = pygame.image.load(image_path)
            # Scale to tile size (assuming 64x64 for this example, or adaptable)
            self.image = pygame.transform.scale(self.image, (64, 64))

    @abstractmethod
    def interact(self, agent):
        """
        Polymorphic method - KEY OOP PRINCIPLE.
        Each subclass defines how it interacts with the agent.
        Returns: (can_move, reward, done)
        """
        pass

    def render(self, screen, tile_size):
        if self.image:
            rect = self.image.get_rect()
            rect.topleft = (self.x * tile_size, self.y * tile_size)
            screen.blit(self.image, rect)
        else:
            # Fallback rendering if no image
            pygame.draw.rect(screen, self.color, 
                             (self.x * tile_size, self.y * tile_size, tile_size, tile_size))

# --- OOP: Polymorphism (Concrete Classes) ---

class Floor(GameObject):
    """Walkable floor tile"""
    def __init__(self, x, y):
        super().__init__(x, y, "floor.png", color=(240, 240, 240))

    def interact(self, agent):
        # Floor is walkable - small time penalty
        return True, -0.01, False  # (can_move, reward, done)

class Wall(GameObject):
    """
    NEW: Wall obstacle - demonstrates polymorphism!
    Different interact() behavior than Floor/Package.
    """
    def __init__(self, x, y):
        super().__init__(x, y, image_path=None, color=(60, 60, 60))

    def interact(self, agent):
        # Wall blocks movement - penalty for hitting wall
        return False, -0.5, False  # (can_move, reward, done)

class Package(GameObject):
    """Goal object - collecting it ends the episode"""
    def __init__(self, x, y):
        super().__init__(x, y, "package.png", color=(255, 215, 0))

    def interact(self, agent):
        # Package collected - large reward and episode ends
        return True, 100.0, True  # (can_move, reward, done)

class Robot(GameObject):
    """The agent controlled by the player or AI"""
    def __init__(self, x, y):
        super().__init__(x, y, "bot_blue.png", color=(50, 150, 255))
    
    def interact(self, agent):
        # Self-interaction shouldn't happen, but needed for completeness
        return False, 0, False

    def move(self, dx, dy, grid_width, grid_height):
        """Calculate new position with boundary checking"""
        new_x = max(0, min(grid_width - 1, self.x + dx))
        new_y = max(0, min(grid_height - 1, self.y + dy))
        return new_x, new_y

# --- Gymnasium Environment ---

class WarehouseEnv(gym.Env):
    """
    Custom Gymnasium Environment for Warehouse Robot.
    Demonstrates OOP principles through GameObject hierarchy.
    """
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 10}

    def __init__(self, grid_size=8, wall_density=0.15, max_steps=200, render_mode=None):
        super().__init__()
        self.grid_size = grid_size
        self.wall_density = wall_density
        self.max_steps = max_steps
        self.window_size = 64 * grid_size
        self.render_mode = render_mode
        self.window = None
        self.clock = None

        # Action space: 0=Up, 1=Right, 2=Down, 3=Left
        self.action_space = spaces.Discrete(4)
        
        # Observation space: Robot (x, y) and Package (x, y)
        self.observation_space = spaces.Box(
            low=0, high=grid_size-1, shape=(4,), dtype=np.int32
        )

        self._agent = None
        self._target = None
        self._walls = []
        self.objects = []  # Floor tiles
        self.current_step = 0
        self.total_reward = 0

    def _get_obs(self):
        return np.array([self._agent.x, self._agent.y, self._target.x, self._target.y], dtype=np.int32)

    def _get_info(self):
        distance = abs(self._agent.x - self._target.x) + abs(self._agent.y - self._target.y)
        return {
            "distance": distance,
            "steps": self.current_step,
            "total_reward": self.total_reward
        }

    def _manhattan_distance(self, x1, y1, x2, y2):
        return abs(x1 - x2) + abs(y1 - y2)

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        
        self.current_step = 0
        self.total_reward = 0
        
        # 1. Create Floor Grid
        self.objects = []
        for x in range(self.grid_size):
            for y in range(self.grid_size):
                self.objects.append(Floor(x, y))

        # 2. Generate Walls (randomly placed obstacles)
        self._walls = []
        num_walls = int(self.grid_size * self.grid_size * self.wall_density)
        wall_positions = set()
        
        while len(wall_positions) < num_walls:
            wx = self.np_random.integers(0, self.grid_size)
            wy = self.np_random.integers(0, self.grid_size)
            # Don't place wall at corners (potential spawn points)
            if (wx, wy) not in [(0, 0), (self.grid_size-1, self.grid_size-1)]:
                wall_positions.add((wx, wy))
        
        for wx, wy in wall_positions:
            self._walls.append(Wall(wx, wy))

        # 3. Spawn Agent (avoid walls)
        agent_placed = False
        while not agent_placed:
            ax = self.np_random.integers(0, self.grid_size)
            ay = self.np_random.integers(0, self.grid_size)
            if not any(w.x == ax and w.y == ay for w in self._walls):
                self._agent = Robot(ax, ay)
                agent_placed = True
        
        # 4. Spawn Package (avoid walls and agent, ensure some distance)
        package_placed = False
        while not package_placed:
            tx = self.np_random.integers(0, self.grid_size)
            ty = self.np_random.integers(0, self.grid_size)
            # Ensure package is not on wall, not on agent, and at least 3 tiles away
            if (not any(w.x == tx and w.y == ty for w in self._walls) and
                not (tx == self._agent.x and ty == self._agent.y) and
                self._manhattan_distance(tx, ty, self._agent.x, self._agent.y) >= 3):
                self._target = Package(tx, ty)
                package_placed = True

        if self.render_mode == "human":
            self._render_frame()

        return self._get_obs(), self._get_info()

    def step(self, action):
        self.current_step += 1
        
        # Map action to direction
        direction = {
            0: (0, -1),  # Up
            1: (1, 0),   # Right
            2: (0, 1),   # Down
            3: (-1, 0)   # Left
        }[action]

        # Calculate tentative position
        target_x, target_y = self._agent.move(direction[0], direction[1], 
                                               self.grid_size, self.grid_size)

        # Check interaction - KEY POLYMORPHISM DEMONSTRATION
        # We call interact() without knowing the specific object type!
        interaction_result = None
        
        # Check if target position has a wall
        wall_at_target = next((w for w in self._walls if w.x == target_x and w.y == target_y), None)
        if wall_at_target:
            interaction_result = wall_at_target.interact(self._agent)
        # Check if target position has the package
        elif target_x == self._target.x and target_y == self._target.y:
            interaction_result = self._target.interact(self._agent)
        else:
            # It's a floor tile
            floor_obj = next((o for o in self.objects if o.x == target_x and o.y == target_y), None)
            if floor_obj:
                interaction_result = floor_obj.interact(self._agent)

        can_move, reward, terminated = interaction_result

        # Add distance-based reward shaping (small bonus for getting closer)
        old_distance = self._manhattan_distance(self._agent.x, self._agent.y, 
                                                  self._target.x, self._target.y)
        
        # Move agent if allowed
        if can_move:
            self._agent.x = target_x
            self._agent.y = target_y
            
            # Calculate new distance and add shaping reward
            new_distance = self._manhattan_distance(self._agent.x, self._agent.y,
                                                      self._target.x, self._target.y)
            distance_reward = (old_distance - new_distance) * 0.1
            reward += distance_reward

        self.total_reward += reward

        # Check if max steps reached
        truncated = self.current_step >= self.max_steps

        if self.render_mode == "human":
            self._render_frame()

        return self._get_obs(), reward, terminated, truncated, self._get_info()

    def render(self):
        if self.render_mode == "rgb_array":
            return self._render_frame()

    def _render_frame(self):
        if self.window is None and self.render_mode == "human":
            pygame.init()
            pygame.display.init()
            self.window = pygame.display.set_mode((self.window_size, self.window_size))
            pygame.display.set_caption("Warehouse Robot - OOP Demo")
        
        if self.clock is None and self.render_mode == "human":
            self.clock = pygame.time.Clock()

        canvas = pygame.Surface((self.window_size, self.window_size))
        canvas.fill((255, 255, 255))
        
        tile_size = 64

        # Draw floor tiles
        for obj in self.objects:
            obj.render(canvas, tile_size)

        # Draw walls (polymorphic rendering)
        for wall in self._walls:
            wall.render(canvas, tile_size)

        # Draw target package
        self._target.render(canvas, tile_size)

        # Draw agent robot
        self._agent.render(canvas, tile_size)

        # Draw grid lines for clarity
        for i in range(self.grid_size + 1):
            pygame.draw.line(canvas, (200, 200, 200), 
                           (i * tile_size, 0), (i * tile_size, self.window_size), 1)
            pygame.draw.line(canvas, (200, 200, 200), 
                           (0, i * tile_size), (self.window_size, i * tile_size), 1)

        if self.render_mode == "human":
            self.window.blit(canvas, canvas.get_rect())
            pygame.event.pump()
            pygame.display.update()
            self.clock.tick(self.metadata["render_fps"])
        else:
            return np.transpose(
                np.array(pygame.surfarray.pixels3d(canvas)), axes=(1, 0, 2)
            )

    def close(self):
        if self.window is not None:
            pygame.display.quit()
            pygame.quit()
