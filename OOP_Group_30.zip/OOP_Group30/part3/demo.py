import gymnasium as gym
import pygame
from warehouse_env import WarehouseEnv
from agent import QLearningAgent
import time
import os

def demo_trained_agent(model_path="models/best_agent.pkl", num_episodes=5, delay=0.3):
    """
    Demonstrate the trained agent playing the warehouse environment.
    
    Args:
        model_path: Path to saved agent model
        num_episodes: Number of episodes to demonstrate
        delay: Delay between steps (seconds) for visualization
    """
    print("="*60)
    print("WAREHOUSE ROBOT - TRAINED AGENT DEMONSTRATION")
    print("="*60)
    
    # Create environment with rendering
    env = WarehouseEnv(grid_size=8, wall_density=0.15, max_steps=200, render_mode="human")
    
    # Create and load agent
    agent = QLearningAgent(action_space_size=env.action_space.n)
    
    if not agent.load(model_path):
        print(f"\nERROR: Could not load agent from {model_path}")
        print("Please train the agent first by running: python train.py")
        env.close()
        return
    
    print(f"\nAgent Statistics:")
    stats = agent.get_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    print(f"\nRunning {num_episodes} demonstration episodes...")
    print("Press ESC to quit early\n")
    
    successes = 0
    total_reward = 0
    total_steps = 0
    
    for episode in range(num_episodes):
        observation, info = env.reset()
        episode_reward = 0
        done = False
        truncated = False
        steps = 0
        
        print(f"\nEpisode {episode + 1}/{num_episodes}")
        print(f"  Starting position: ({observation[0]}, {observation[1]})")
        print(f"  Package position: ({observation[2]}, {observation[3]})")
        print(f"  Initial distance: {info['distance']}")
        
        while not (done or truncated):
            # Check for quit event
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    env.close()
                    return
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    env.close()
                    return
            
            # Agent selects action (greedy, no exploration)
            action = agent.select_action(observation, training=False)
            
            # Take action
            observation, reward, done, truncated, info = env.step(action)
            episode_reward += reward
            steps += 1
            
            # Render
            env.render()
            time.sleep(delay)
        
        # Episode summary
        success = done and not truncated
        if success:
            successes += 1
            print(f"  ✓ SUCCESS! Reached package in {steps} steps")
        else:
            print(f"  ✗ FAILED - Timeout after {steps} steps")
        
        print(f"  Total reward: {episode_reward:.2f}")
        
        total_reward += episode_reward
        total_steps += steps
        
        time.sleep(1)  # Pause between episodes
    
    # Final statistics
    print("\n" + "="*60)
    print("DEMONSTRATION COMPLETE")
    print("="*60)
    print(f"Success Rate: {successes}/{num_episodes} ({successes/num_episodes*100:.1f}%)")
    print(f"Average Reward: {total_reward/num_episodes:.2f}")
    print(f"Average Steps: {total_steps/num_episodes:.1f}")
    
    env.close()


if __name__ == "__main__":
    # Check if model exists
    model_path = "models/best_agent.pkl"
    
    if not os.path.exists(model_path):
        print("No trained model found!")
        print("Please train the agent first by running:")
        print("  python train.py")
    else:
        demo_trained_agent(model_path=model_path, num_episodes=5, delay=0.2)
