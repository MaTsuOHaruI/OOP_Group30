import gymnasium as gym
import pygame
from warehouse_env import WarehouseEnv
import time

def main():
    """
    Manual control mode for Warehouse Robot.
    Play the game yourself using arrow keys!
    """
    print("="*60)
    print("WAREHOUSE ROBOT - MANUAL CONTROL MODE")
    print("="*60)
    print("\nControls:")
    print("  ↑ ↓ ← → : Move Robot")
    print("  ESC     : Quit")
    print("\nGoal: Navigate the robot to collect the package!")
    print("Avoid walls (dark gray squares)\n")
    
    # Create the custom environment
    env = WarehouseEnv(grid_size=8, wall_density=0.15, max_steps=200, render_mode="human")
    
    observation, info = env.reset()
    
    # Game statistics
    total_episodes = 0
    successful_episodes = 0
    
    running = True
    episode_reward = 0
    episode_steps = 0
    
    print(f"Episode 1 started!")
    print(f"  Package at: ({observation[2]}, {observation[3]})")
    print(f"  Distance: {info['distance']} tiles\n")
    
    while running:
        # Event handling
        action = None
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    action = 0
                elif event.key == pygame.K_RIGHT:
                    action = 1
                elif event.key == pygame.K_DOWN:
                    action = 2
                elif event.key == pygame.K_LEFT:
                    action = 3
                elif event.key == pygame.K_ESCAPE:
                    running = False
        
        # If an action was taken, step the environment
        if action is not None:
            observation, reward, terminated, truncated, info = env.step(action)
            episode_reward += reward
            episode_steps += 1
            
            # Check if episode ended
            if terminated or truncated:
                total_episodes += 1
                
                if terminated:
                    successful_episodes += 1
                    print(f"🎉 SUCCESS! Package collected in {episode_steps} steps!")
                    print(f"   Episode reward: {episode_reward:.2f}")
                else:
                    print(f"⏱️  Timeout! Reached max steps ({episode_steps})")
                    print(f"   Episode reward: {episode_reward:.2f}")
                
                print(f"\nOverall Statistics:")
                print(f"  Episodes: {total_episodes}")
                print(f"  Success Rate: {successful_episodes}/{total_episodes} "
                      f"({successful_episodes/total_episodes*100:.1f}%)")
                
                # Reset for next episode
                observation, info = env.reset()
                episode_reward = 0
                episode_steps = 0
                
                print(f"\nEpisode {total_episodes + 1} started!")
                print(f"  Package at: ({observation[2]}, {observation[3]})")
                print(f"  Distance: {info['distance']} tiles\n")
        
        # Render the environment
        env.render()
        
        # Small sleep to prevent high CPU usage
        time.sleep(0.01)

    env.close()
    
    print("\n" + "="*60)
    print("GAME OVER")
    print("="*60)
    print(f"Total Episodes: {total_episodes}")
    if total_episodes > 0:
        print(f"Success Rate: {successful_episodes}/{total_episodes} "
              f"({successful_episodes/total_episodes*100:.1f}%)")
    print("\nThanks for playing!")

if __name__ == "__main__":
    main()

