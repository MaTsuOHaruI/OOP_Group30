import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
import pickle

class ModelBasedAgent:
    def __init__(self, n_states, n_actions, gamma=0.99, epsilon=1.0, epsilon_decay=0.00015, min_epsilon=0.0):
        self.n_states = n_states
        self.n_actions = n_actions
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.min_epsilon = min_epsilon
        
        # Q-table for action values
        self.q_table = np.zeros((n_states, n_actions))
        # Model-based components
        self.transition_counts = np.zeros((n_states, n_actions, n_states))
        self.reward_sums = np.zeros((n_states, n_actions, n_states))
        self.model_prob = np.zeros((n_states, n_actions, n_states))
        self.model_rewards = np.zeros((n_states, n_actions, n_states))
        self.V = np.zeros(n_states)
    
    def choose_action(self, state, training=True):
        if training and np.random.rand() < self.epsilon:
            return np.random.randint(self.n_actions)
        else:
            return np.argmax(self.q_table[state])
    
    def update_q(self, state, action, reward, next_state):
        self.q_table[state, action] += 0.1 * (
            reward + self.gamma * np.max(self.q_table[next_state]) - self.q_table[state, action]
        )
    
    def update_model(self, state, action, reward, next_state):
        self.transition_counts[state, action, next_state] += 1
        self.reward_sums[state, action, next_state] += reward
        # Update probabilities and average reward
        total = np.sum(self.transition_counts[state, action])
        if total > 0:
            self.model_prob[state, action, :] = self.transition_counts[state, action, :] / total
            self.model_rewards[state, action, :] = np.divide(
                self.reward_sums[state, action, :],
                self.transition_counts[state, action, :],
                out=np.zeros_like(self.reward_sums[state, action, :]),
                where=self.transition_counts[state, action, :] != 0
            )
    
    def value_iteration(self):
        Q = np.zeros((self.n_states, self.n_actions))
        for s in range(self.n_states):
            for a in range(self.n_actions):
                Q[s,a] = np.sum(
                    self.model_prob[s,a,:] * (self.model_rewards[s,a,:] + self.gamma * self.V)
                )
        self.V = np.max(Q, axis=1)
        self.q_table = Q
    
    def decay_epsilon(self):
        self.epsilon = max(self.min_epsilon, self.epsilon * (1 - self.epsilon_decay))


def run_agent(episodes=15000, render=False):
    env = gym.make('FrozenLake-v1', map_name="4x4", is_slippery=True, render_mode='human' if render else None)
    
    agent = ModelBasedAgent(env.observation_space.n, env.action_space.n, gamma=0.99, epsilon=1.0, epsilon_decay=0.00015, min_epsilon=0.05)
    
    rewards_per_episode = np.zeros(episodes)
    
    for ep in range(episodes):
        state, _ = env.reset()
        terminated = False
        truncated = False
        
        while not terminated and not truncated:
            action = agent.choose_action(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            
            agent.update_q(state, action, reward, next_state)
            agent.update_model(state, action, reward, next_state)
            
            state = next_state
        
        # Run Value Iteration every episode (after episode 100)
        if ep >= 100:
            agent.value_iteration()
        
        agent.decay_epsilon()
        rewards_per_episode[ep] = reward
    
    env.close()
    
    # Save agent
    with open('model_based_agent.pkl', 'wb') as f:
        pickle.dump(agent, f)
    
    # Plot moving sum of rewards
    sum_rewards = [np.sum(rewards_per_episode[max(0, t-100):(t+1)]) for t in range(episodes)]
    plt.plot(sum_rewards)
    plt.xlabel("Episode")
    plt.ylabel("Sum of rewards (last 100)")
    plt.title("Learning Progress")
    plt.savefig("model_based_learning.png")
    
    # Print success rate
    total_success = np.sum(rewards_per_episode)
    success_rate = total_success / episodes
    print(f"Success Rate: {success_rate*100:.2f}% ({int(total_success)} / {episodes} episodes)")

    return agent

def evaluate_agent(agent, episodes=1000, render = True):
    env = gym.make('FrozenLake-v1', map_name="4x4", is_slippery=True, render_mode="ansi" if render else None)
    rewards_per_episode = np.zeros(episodes)
    
    for ep in range(episodes):
        state, _ = env.reset()
        terminated = False
        truncated = False
        
        while not terminated and not truncated:
            action = agent.choose_action(state, training=False)
            state, reward, terminated, truncated, _ = env.step(action)
        rewards_per_episode[ep] = reward
    
    env.close()
    total_success = np.sum(rewards_per_episode)
    success_rate = total_success / episodes
    print(f"Evaluation Success Rate: {success_rate*100:.2f}% ({int(total_success)} / {episodes} episodes)")
    return success_rate

if __name__ == "__main__":
    agent = run_agent(episodes=15000, render=False)
    evaluate_agent(agent, episodes=1000, render=True)
